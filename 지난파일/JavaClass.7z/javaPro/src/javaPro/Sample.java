package javaPro;

	public class Sample {

		public static void main(String[] arhs) {

			String name = "강명건";
			int age = 31;


			System.out.printf("이름 : \"%s\", 나이 : %d살입니다.",name, age);
		}
}