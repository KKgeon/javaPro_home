package days10;

public class Ex03 {
	public static void main(String[] args) {

		/*
		 * [배열] + 제어문(for문)
		 * 1. 
		 */
	}//m
}//c
