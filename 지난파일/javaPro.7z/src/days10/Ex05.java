package days10;

public class Ex05 {
	public static void main(String[] args) {
		
	}//m
}//c
