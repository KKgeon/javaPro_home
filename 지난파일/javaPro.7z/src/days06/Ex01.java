package days06;

public class Ex01 {

}
