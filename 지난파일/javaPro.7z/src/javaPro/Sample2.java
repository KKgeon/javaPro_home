package javaPro;

import java.util.Iterator;
import java.util.Scanner;

public class Sample2 {

	public static void main(String[] args) {
		
		int [] m = new int [10];
		
		
		for (int i = 0; i < m.length; i++) {
			m[i] = (int) (Math.random() * 10);
			System.out.printf("[%d]", m[i]);
		
	}

}
}
