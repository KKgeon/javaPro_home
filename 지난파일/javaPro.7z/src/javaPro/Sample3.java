package javaPro;

import java.util.Scanner;

public class Sample3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);



		System.out.println("> 한 문자 입력 ? a 엔터");
		char a = sc.next().charAt(0);
		System.out.printf("one=\'%c\'\n", a);
		System.out.println("> 한 문자 입력 ? b 엔터");
		char b = sc.next().charAt(0);
		System.out.printf("one=\'%c\'", b);
	}
}
