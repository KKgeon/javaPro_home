package days05;

/**
 * @author geon
 * @date 2024. 1. 5. - 오후 12:30:21
 * @subject
 * @content
 */
public class Ex04 {
	public static void main(String[] args) {
		/*
		for (int i = 'A'; i <= 'Z'; i++) {
		System.out.printf("%c(%d)\n", i, i);	
		}
		*/
		/*
		for (int i = '가'; i <= '힣'; i++) {
			System.out.printf("%c(%d)\n", i, i);
			}
		*/
		/*
		for (int i = 'ㄱ'; i <= 'ㅎ'; i++) {
			System.out.printf("%c(%d)\n", i, i);			
		}
		*/
		for (int i = 'ㅏ'; i <= 'ㅣ'; i++) {
			System.out.printf("%c(%d)\n", i, i);
		}
		
		
	}
}
