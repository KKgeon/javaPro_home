package days01;

public class Ex04_02 {
	
	public static void main(String[] args) {
		
		// + 산술연산자(덧셈)
		System.out.println( 3 + 5 ); //8
		
		// + 산술연산자 X, 문자열 연결연산자
		System.out.println( "3" + 5 ); //"35"
		
		System.out.println( "3" + "5" ); //"35"
	}//main

}//class
