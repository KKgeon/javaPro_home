package days01;

public class Ex05 {
	
	public static void main(String[] args) {
		
	}//main

}//class

