package days09;

public class Ex01 {
	public static void main(String[] args) {
		//[거듭제곱] == 누승 == 멱 == pow
		// 밑수(2)를 지수(3)만큼 반복해서 곱하는 것.
		// 2^3 = 2*2*2=8
		// 2^-3 = 1/ (2^3) = 8/1 = 0.125
////		double result = recursivePow(2,3);
//		double result = recursivePow(2,3);
//		System.out.println(result);
//
//	}///m
//
//	private static double recursivePow(int n, int m) {
//		if(m>1) return n * recursivePow(n, m-1);
////		if (m == 1)  return n;
////		m==0 re 1
////		else 		return 1/ n -recursivePow(1*m);
		
	}
}///c
