package days09;

/**
 * @author geon
 * @date 2024. 1. 11. - 오전 11:10:47
 * @subject
 * @content
 */
public class Ex03 {
	public static void main(String[] args) {
		String rrn = "830412-1700001";
		System.out.println(rrn.substring(0, 8).concat("******"));
	}
}
