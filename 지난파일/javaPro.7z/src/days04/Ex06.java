package days04;

/**
 * @author geon
 * @date 2024. 1. 4. - 오후 3:39:45
 * @subject
 * @content
 */
public class Ex06 {
	public static void main(String[] args) {

		for (int i = 1; i <=10; i++) {
				System.out.println("강명건");

			/*
		for (초기식; 조건식; 증감식) {

		}
		
		 조건식 : 참/거짓으로 판단하는 수식
      
      초기식 : 초기화 수식
        ㄴ  변수 초기화
        int i = 10;
        int i;
        i = 10;

			 */
		}
	}

}
