package days14;

public class Time {
	//field
		public int hour;
		int minute;
		protected int second;
		private int millisecond;

		//method


		public void privateTest() {
			millisecond	= 1;
			hour = 1;
			minute = 1;
			second = 1;
		}
}
