package days14;

public class Ex03 {
	public static void main(String[] args) {
//		The local variable m may not have been initialized
		//		int [] m = null;
//		int [] m = new int [3];

		//NullPointerException
		//ArrayIndexOutOfBoundsException
//		System.out.println(m[3]);
		
		
		//The local variable tv1 may not have been initialized
		//NullPointerException
		Tv tv1 = null;
		System.out.println(tv1.channel);
		
		
	}//m
}//c
