package days14;

public class Ex10_04 {
	public static void main(String[] args) {
		 Point p1 = new Point();
	      p1.x = 10;
	      p1.y = 20;
	      

	      p1
	      	.moveNewPoint(100)
	      	.dispXY();
	      
//	      Point p = p1.moveNewPoint(100);
//	      p.dispXY();
	      
//	      p1.movePoint(100).dispXY(); movePoint() 함수는 리턴값이 클래스가 아니고 보이드라서 안됨~~
	}//m
}//c
