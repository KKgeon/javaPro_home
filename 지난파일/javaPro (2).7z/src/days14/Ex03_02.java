package days14;

import java.util.Random;
import java.util.Scanner;

public class Ex03_02 {
	public static void main(String[] args) {

		
		//System 클래스 - 표준 입출력 스트림 필드
		//					표준 입출력 메서드
		
		//System s1 = new System(); X 인스턴스화할수없는 클래스이다.
		
		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();
		
		//[문제] 스캐너 객체를 생성만 하는 코딩을 하세요
		//				인스턴스화
		// [답] new Scanner(System.in)
	}//m
}//c
