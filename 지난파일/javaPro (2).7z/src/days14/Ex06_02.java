package days14;

public class Ex06_02 {

	public static void main(String[] args) {
		// [클래스 배열 초기화]
		/*
		 * Tv [] tvArr = new Tv[3]
		 * tvArr[0] = new Tv();
		 * tvArr[1] = new Tv();
		 * tvArr[2] = new Tv();
		*/
		Tv [] tvArr = {new Tv(),new Tv(),new Tv()};
		
	}//main

}//class
