package days04;

/**
 * @author geon
 * @date 2024. 1. 4. - 오후 12:39:59
 * @subject
 * @content
 */
public class Ex04 {

	public static void main(String[] args) {

		String kor = "    89   ";
		// 문자열에서 앞 뒤 공백 제거 코딩.  String.trim(); 문자열의 앞뒤 공백을 지우는 클래스
		System.out.printf("[%s]\n", kor.trim());
	}

}
