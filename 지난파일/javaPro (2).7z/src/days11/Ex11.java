package days11;

/**
 * @author geon
 * @date 2024. 1. 15. - 오후 5:14:40
 * @subject
 * @content
 */
public class Ex11 {
	public static void main(String[] args) {
			/*
			 * 
			 * 
			 * [다차원 배열은 배열의 배열이다]
			 */
		
		//1차원배열
		int [] m = new int [8];
		//0~7
		
		//2차원배열 - 4행2열
		int [][] m2 = new int [2][4];
		
		int [][][] m3 = new int [2][2][2];
		
		int []kors = new int [30*10*3];
		
		
	}//m
}//c
