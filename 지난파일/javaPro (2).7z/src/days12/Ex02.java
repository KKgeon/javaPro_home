package days12;

public class Ex02 {
	public static void main(String[] args) {
		//다차원배열 - 배열의 배열이다.
		//배열은 초기화하지 않아도 그 자료형의 기본값으로 초기화 되어져 있다.
		
		/*
		int []m = new int[8];
//		m[0]~m[m.length-1]
		System.out.println(m.length); //배열크기
		System.out.println(m.length-1);// 배열 upperbound
		
		*/
		/*
		int []m = new int[3];
		m[0]=1;
		m[1]=2;
		m[2]=3;
		*/
		//배열초기화
		
		/*
		int [] m = new int {1,2,3};
		int [] m = {1,2,3);
		
		*/
	}//m
}//c
