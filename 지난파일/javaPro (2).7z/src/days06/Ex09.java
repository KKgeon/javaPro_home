package days06;

/**
 * @author geon
 * @date 2024. 1. 8. - 오후 5:28:29
 * @subject
 * @content
 */
public class Ex09 {
	public static void main(String[] args) {

	}
}
