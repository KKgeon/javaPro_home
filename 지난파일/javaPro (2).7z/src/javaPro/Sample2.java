package javaPro;

public class Sample2 {

	public static void main(String[] args) {





	}//m
}//c
