package javaPro;

import java.util.Scanner;

public class Ex0108_01 {

	public static void main(String[] args) {
		int a, b, c;
		try (Scanner sc = new Scanner(System.in)) {
			a = sc.nextInt();
			b = sc.nextInt();
			c = sc.nextInt();
			
//			int max = a> b ? a > (c ? a : c : b) > (c ? b : c);
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
