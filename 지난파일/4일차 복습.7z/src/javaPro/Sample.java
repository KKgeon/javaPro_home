public class Sample {
	public static void main(String[] args) {

		int sum = 0;
		for (int i = 0; i <= 10; i++) {
			System.out.printf("%d+", i);
			sum = sum + i;		//sum += i;				
		}
		System.out.printf("\b%d\n", sum);
	}
	}
