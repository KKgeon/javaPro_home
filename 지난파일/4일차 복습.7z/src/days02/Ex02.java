package days02;

public class Ex02 {

	//	String name; 지역변수 X
	public static void main(String[] args) {
		// 지역변수(local variable)는 반드시 초기화해야 사용할 수 있다.
		//The value of the local variable name is not used
		String name; // 지역변수 O 위치에 따라 바뀜, 초기화하지 않으면 경고 뜸


	}

}
