package days03;

/**
 * @author geon
 * @date 2024. 1. 3. - 오후 4:22:09
 * @subject	산술 연산자
 * @content	ㄴ [비트]시프트(shift) 연산자
 * 			 물건을	이동시키다
 * 					옮기다 라는 뜻
 					바꾸다
 */
public class Ex06_03 {
	public static void main(String[] args) {
					//0000 1010
		System.out.println(10);
		System.out.println(10>>2);//2
		System.out.println(10>>>2);//2
		System.out.println(10<<2);//40
		//시프트 연산자는 비트 안에서의 2진수를 좌우측으로 이동시키는 연산자이다.

	}

}
