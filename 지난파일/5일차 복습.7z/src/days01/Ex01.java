package days01;


/**
 * @author geon
 * @date 2023. 12. 29. - 오후 2:33:26
 * @subject 수업 1일차 첫번째 예제
 * @content JDK 11 설치 및 확인
 * 			자바 프로그램의 기본 구조 설명
 * 			자바 클래스 선언 형식
 * 			자바 함수(메서드) 선언 형식
 */
public class Ex01{
	public static void main(String [] args) {//프로그램시작
	}
}//종료