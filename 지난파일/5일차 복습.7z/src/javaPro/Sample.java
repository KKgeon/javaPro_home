package javaPro;

public class Sample {
	public static void main(String[] args) {   
		int com = 0;
		int user = 0;
		String [] rps = { "", "가위", "바위", "보" };

		System.out.printf("컴퓨터:%s, 사용자는:%s\n", rps[com],rps[user]);

		//승자 패자
		switch ( user - com ) {
		case -2:case 1:
			System.out.println("사용자 승리");
			break;
		case -1:case 2:
			System.out.println("컴퓨터 승리");
		default:System.out.println("무승부");
		break;

		}
	}
}