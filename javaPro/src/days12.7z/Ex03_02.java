package days12;

/**
 * @author geon
 * @date 2024. 1. 16. - 오전 11:20:28
 * @subject	세개 반의 23명 학생들의 이름 국어 영어 수학 평균 총점 반등수 전교등수 처리하는 코딩.
 * @content [숙제]
 */
public class Ex03_02 {
	public static void main(String[] args) {
		final int STUDENT_COUNT = 23;
		final int CLASS_COUNT = 3;


		String [][] names = new String[CLASS_COUNT][STUDENT_COUNT];
		double [][] avgs = new double[CLASS_COUNT][STUDENT_COUNT];
		int [][][] infos = new int[CLASS_COUNT][STUDENT_COUNT][6];

		int [] counts = new int[CLASS_COUNT];

				char con = 'y';



	}
}
