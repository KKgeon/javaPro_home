package days12;

public class Ex08 {
	public static void main(String[] args) {

	}//m
}//c
