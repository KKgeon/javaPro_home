package days12;

/**
 * @author geon
 * @date 2024. 1. 16. - 오전 10:15:46
 * @subject 클래스 수업 시작
 * @content
 */
public class Ex01 {
	public static void main(String[] args) {
		//main()의 매개변수 String[]args ?
		
		System.out.println("end");
		for (int i = 0; i < args.length; i++) {
			System.out.printf("[%d] - %s\n",i, args[i]);
			
		}
		
		
	}//m
}//c
