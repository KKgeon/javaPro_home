package javaPro;

import java.util.Scanner;

public class Sample4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a, b;
		
		System.out.println("> 첫번째 수 입력 ?");
		a = sc.nextInt();
		System.out.println("> 두번째 수 입력 ?");
		b = sc.nextInt();

		int min = a < b ? a : b;
		int max = a < b ? b : a;

		int sum = 0;
		for (int i = min; i <= max; i++) {
			if (i % 2 == 0) {
				sum = sum + i;
				System.out.printf("%d+", i);				
			}
			
		}
		System.out.printf("\b=%d\n", sum);
		
	}

}
