package javaPro;

public class Sample {
	public static void main(String[] args) {  



		for (int i = 'A'; i <= 'Z'; i++) {
			System.out.printf("%c(%d)\n", i, i);
			if (i % 10 == 0) {System.out.printf("%d : ", i/10+1);}
			System.out.printf("[%c]", i);
			if (i % 10 == 9) {
				System.out.println();
			}
		}
	}
}