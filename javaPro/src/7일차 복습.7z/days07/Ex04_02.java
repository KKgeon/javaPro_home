package days07;

public class Ex04_02 {

	public static void main(String[] args) {
		int [] kors = {99, 1, 100, -10, 101};
		String regex = "\\d{3}";
		
		for (int i = 0; i < kors.length; i++) {
			int kor = kors[i];
			//미완 못따라감
		}
	}

}
