package days08;

import com.util.Draw2D;

public class Ex01 {

	public static void main(String[] args) {
		
	}
}
